import { Component } from '@angular/core';

@Component({
  selector: 'app-detalle-tomate',
  standalone: true,
  imports: [],
  templateUrl: './detalle-tomate.component.html',
  styleUrl: './detalle-tomate.component.css'
})
export class DetalleTomateComponent {

}
