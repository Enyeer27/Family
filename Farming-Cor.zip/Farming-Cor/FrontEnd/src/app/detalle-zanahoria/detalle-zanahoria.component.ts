import { Component } from '@angular/core';

@Component({
  selector: 'app-detalle-zanahoria',
  standalone: true,
  imports: [],
  templateUrl: './detalle-zanahoria.component.html',
  styleUrl: './detalle-zanahoria.component.css'
})
export class DetalleZanahoriaComponent {

}
