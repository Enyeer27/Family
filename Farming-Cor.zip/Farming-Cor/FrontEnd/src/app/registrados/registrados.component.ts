import { Component } from '@angular/core';

@Component({
  selector: 'app-registrados',
  standalone: true,
  imports: [],
  templateUrl: './registrados.component.html',
  styleUrl: './registrados.component.css'
})
export class RegistradosComponent {

}
