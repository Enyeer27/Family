import { Component } from '@angular/core';

@Component({
  selector: 'app-form-registrados',
  standalone: true,
  imports: [],
  templateUrl: './form-registrados.component.html',
  styleUrl: './form-registrados.component.css'
})
export class FormRegistradosComponent {

}
