import { Component } from '@angular/core';

@Component({
  selector: 'app-pag-prin-administrador',
  standalone: true,
  imports: [],
  templateUrl: './pag-prin-administrador.component.html',
  styleUrl: './pag-prin-administrador.component.css'
})
export class PagPrinAdministradorComponent {

}
