import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormProdProveedorComponent } from './form-prod-proveedor.component';

describe('FormProdProveedorComponent', () => {
  let component: FormProdProveedorComponent;
  let fixture: ComponentFixture<FormProdProveedorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormProdProveedorComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FormProdProveedorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
