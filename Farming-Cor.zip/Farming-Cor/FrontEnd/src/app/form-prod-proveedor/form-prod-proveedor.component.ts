import { Component } from '@angular/core';

@Component({
  selector: 'app-form-prod-proveedor',
  standalone: true,
  imports: [],
  templateUrl: './form-prod-proveedor.component.html',
  styleUrl: './form-prod-proveedor.component.css'
})
export class FormProdProveedorComponent {

}
