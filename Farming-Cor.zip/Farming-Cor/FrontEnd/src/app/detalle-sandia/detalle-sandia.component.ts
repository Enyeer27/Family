import { Component } from '@angular/core';

@Component({
  selector: 'app-detalle-sandia',
  standalone: true,
  imports: [],
  templateUrl: './detalle-sandia.component.html',
  styleUrl: './detalle-sandia.component.css'
})
export class DetalleSandiaComponent {

}
