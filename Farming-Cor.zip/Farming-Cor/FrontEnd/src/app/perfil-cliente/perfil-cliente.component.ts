import { Component } from '@angular/core';

@Component({
  selector: 'app-perfil-cliente',
  standalone: true,
  imports: [],
  templateUrl: './perfil-cliente.component.html',
  styleUrl: './perfil-cliente.component.css'
})
export class PerfilClienteComponent {

}
