import { Routes } from '@angular/router';
import { ReservacionesComponent } from './reservaciones/reservaciones.component';
import { RegistroComponent } from './registro/registro.component';
import { RegistradosComponent } from './registrados/registrados.component';
import { PerfilClienteComponent } from './perfil-cliente/perfil-cliente.component';
import { PagPrinProveedorComponent } from './pag-prin-proveedor/pag-prin-proveedor.component';
import { PagPrinClienteComponent } from './pag-prin-cliente/pag-prin-cliente.component';
import { PagPrinAdministradorComponent } from './pag-prin-administrador/pag-prin-administrador.component';
import { LoginComponent } from './login/login.component';
import { FormRegistradosComponent } from './form-registrados/form-registrados.component';
import { FormProdProveedorComponent } from './form-prod-proveedor/form-prod-proveedor.component';
import { FormPerfilProveedorComponent } from './form-perfil-proveedor/form-perfil-proveedor.component';
import { FormPerfilClienteComponent } from './form-perfil-cliente/form-perfil-cliente.component';
import { DetalleZanahoriaComponent } from './detalle-zanahoria/detalle-zanahoria.component';
import { DetalleTomateComponent } from './detalle-tomate/detalle-tomate.component';
import { DetalleSandiaComponent } from './detalle-sandia/detalle-sandia.component';
import { DetalleMelonComponent } from './detalle-melon/detalle-melon.component';
import { DetalleMangoComponent } from './detalle-mango/detalle-mango.component';
import { DetalleCilantroComponent } from './detalle-cilantro/detalle-cilantro.component';
import { BienvenidoComponent } from './bienvenido/bienvenido.component';

export const routes: Routes = [
    { path: 'bienvenido', component: BienvenidoComponent},
    { path: 'detalle-cilantro', component: DetalleCilantroComponent},
    { path: 'detalle-mango', component: DetalleMangoComponent},
    { path: 'detalle-melon', component: DetalleMelonComponent},
    { path: 'detalle sandia', component: DetalleSandiaComponent},
    { path: 'detalle-tomate', component: DetalleTomateComponent},
    { path: 'detalle-zanahoria', component: DetalleZanahoriaComponent},
    { path: 'form-perfil-cliente', component: FormPerfilClienteComponent},
    { path: 'form-peril-proveedor', component: FormPerfilProveedorComponent},
    { path: 'form-prod-proveedor', component: FormProdProveedorComponent},
    { path: 'form-registrados', component: FormRegistradosComponent},
    { path: 'login', component: LoginComponent},
    { path: 'pag-prin-administrador', component: PagPrinAdministradorComponent},
    { path: 'pag-prin-cliente', component: PagPrinClienteComponent},
    { path: 'pag-prin-proveedor', component: PagPrinProveedorComponent},
    { path: 'perfil-cliente', component: PerfilClienteComponent},
    { path: 'registrados', component: RegistradosComponent},
    { path: 'registro', component: RegistroComponent},
    { path: 'reservaciones', component: ReservacionesComponent}
    
];

  export class AppRoutingModule { }