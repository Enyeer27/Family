import { Component } from '@angular/core';

@Component({
  selector: 'app-form-perfil-cliente',
  standalone: true,
  imports: [],
  templateUrl: './form-perfil-cliente.component.html',
  styleUrl: './form-perfil-cliente.component.css'
})
export class FormPerfilClienteComponent {

}
