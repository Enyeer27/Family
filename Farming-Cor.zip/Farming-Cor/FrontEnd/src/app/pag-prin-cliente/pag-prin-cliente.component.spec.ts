import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PagPrinClienteComponent } from './pag-prin-cliente.component';

describe('PagPrinClienteComponent', () => {
  let component: PagPrinClienteComponent;
  let fixture: ComponentFixture<PagPrinClienteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PagPrinClienteComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PagPrinClienteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
