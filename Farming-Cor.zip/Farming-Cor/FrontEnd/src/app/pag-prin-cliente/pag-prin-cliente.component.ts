import { Component } from '@angular/core';

@Component({
  selector: 'app-pag-prin-cliente',
  standalone: true,
  imports: [],
  templateUrl: './pag-prin-cliente.component.html',
  styleUrl: './pag-prin-cliente.component.css'
})
export class PagPrinClienteComponent {

}
