import { Component } from '@angular/core';

@Component({
  selector: 'app-reservaciones',
  standalone: true,
  imports: [],
  templateUrl: './reservaciones.component.html',
  styleUrl: './reservaciones.component.css'
})
export class ReservacionesComponent {

}
