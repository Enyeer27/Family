import { Component } from '@angular/core';

@Component({
  selector: 'app-form-perfil-proveedor',
  standalone: true,
  imports: [],
  templateUrl: './form-perfil-proveedor.component.html',
  styleUrl: './form-perfil-proveedor.component.css'
})
export class FormPerfilProveedorComponent {

}
