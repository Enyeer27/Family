import { Component } from '@angular/core';

@Component({
  selector: 'app-detalle-mango',
  standalone: true,
  imports: [],
  templateUrl: './detalle-mango.component.html',
  styleUrl: './detalle-mango.component.css'
})
export class DetalleMangoComponent {

}
