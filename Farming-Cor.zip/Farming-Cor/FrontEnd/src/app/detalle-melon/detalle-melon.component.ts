import { Component } from '@angular/core';

@Component({
  selector: 'app-detalle-melon',
  standalone: true,
  imports: [],
  templateUrl: './detalle-melon.component.html',
  styleUrl: './detalle-melon.component.css'
})
export class DetalleMelonComponent {

}
