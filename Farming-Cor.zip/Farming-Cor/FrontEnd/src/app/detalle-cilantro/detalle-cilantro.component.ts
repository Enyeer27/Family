import { Component } from '@angular/core';

@Component({
  selector: 'app-detalle-cilantro',
  standalone: true,
  imports: [],
  templateUrl: './detalle-cilantro.component.html',
  styleUrl: './detalle-cilantro.component.css'
})
export class DetalleCilantroComponent {

}
