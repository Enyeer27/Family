const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 5000;

// Configuración de la conexión a MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'Proyecto'
});

// Conectar a MySQL
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Configurar CORS después de la inicialización de app
app.use(cors());

// Ruta para registrar un usuario
app.post('/registro', (req, res) => {
  console.log('Recibida solicitud de registro:', req.body);
  // Realiza la inserción en la base de datos en la tabla 'datos'
  const { nombre1, nombre2, apellido1, apellido2, Num_Doc, rol, usuario, correo, password } = req.body;
  const queryString = 'INSERT INTO Datos_Personales (Nombre1, Nombre2, Apellido1, Apellido2, Numero_Doc, Nom_rol, Usuario, Correo, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)';
  const values = [nombre1, nombre2, apellido1, apellido2, Num_Doc, rol, usuario, correo, password];

  db.query(queryString, values, (err, result) => {
    if (err) {
      console.error('Error al registrar usuario en la base de datos:', err);
      res.status(500).json({ error: 'Error interno del servidor' });
    } else {
      console.log('Usuario registrado en la base de datos');
      res.status(200).json({ message: 'Usuario registrado exitosamente' });
    }
  });
});

//inisio de sesion
app.post('/autenticar', (req, res) => {
  const { usuario, password, rol } = req.body;

  console.log('Datos recibidos:', { usuario, password, rol });

  const query = `SELECT * FROM Datos_Personales WHERE Usuario = ? AND password = ? AND Nom_rol = ?`;
  db.query(query, [usuario, password, rol], (error, results) => {
    if (error) {
      console.error('Error en la autenticación:', error);
      return res.status(500).json({ mensaje: 'Error en la autenticación' });
    }

    console.log('Resultados de la consulta:', results);

    if (results.length > 0) {
      return res.json({ mensaje: 'Autenticación exitosa' });
    } else {
      return res.status(401).json({ mensaje: 'Credenciales incorrectas' });
    }
  });
});

/*echo con chatgpt:

//--registro
app.post('/registro', (req, res) => {
  const {
    nombre1,
    nombre2,
    apellido1,
    apellido2,
    tipodoc,
    Num_Doc,
    rol,
    usuario,
    correo,
    password,
  } = req.body;

  console.log('Datos recibidos para registro:', req.body);

  connection.query(
    'INSERT INTO Tipo_Documento (Descripcion) VALUES (?)',
    [tipodoc],
    (error, results) => {
      if (error) {
        console.error('Error en el registro:', error);
        return res.status(500).json({ mensaje: 'Error en el registro' });
      }

      const idTipoDoc = results.insertId;

      connection.query(
        'INSERT INTO Datos_Personales (Id_Tipo_Doc, Numero_Doc, Nombre1, Nombre2, Apellido1, Apellido2, Correo, Usuario, Contraseña) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [idTipoDoc, Num_Doc, nombre1, nombre2, apellido1, apellido2, correo, usuario, password],
        (error, results) => {
          if (error) {
            console.error('Error en el registro:', error);
            return res.status(500).json({ mensaje: 'Error en el registro' });
          }

          const idDatoPersonal = results.insertId;

          connection.query(
            'INSERT INTO Roles (Id_Dato_Personal, Nombre_Rol) VALUES (?, ?)',
            [idDatoPersonal, rol],
            (error, results) => {
              if (error) {
                console.error('Error en el registro:', error);
                return res.status(500).json({ mensaje: 'Error en el registro' });
              }

              res.status(200).json({ mensaje: 'Registro exitoso' });
            }
          );
        }
      );
    }
  );
});

//--iniciar sesion
app.post('/autenticar', (req, res) => {
  const { usuario, password, rol } = req.body;

  // Realiza la autenticación como en tu ejemplo

  if (results.length > 0) {
    // Autenticación exitosa, redirigir según el rol
    if (rol === 'Cliente') {
      // Redirige a la página de cliente
      res.redirect('\pag-prin-cliente');
    } else if (rol === 'Proveedor') {
      // Redirige a la página de proveedor
      res.redirect('\pag-prin-proveedor');
    } else {
      // Rol desconocido, maneja según tus requerimientos
      res.status(401).json({ mensaje: 'Rol desconocido' });
    }
  } else {
    // Autenticación fallida
    return res.status(401).json({ mensaje: 'Credenciales incorrectas' });
  }
});

//--reservaciones
app.post('/reservar', (req, res) => {
  const { --Aquí debes incluir los datos necesarios para la reserva (puedes obtenerlos del cuerpo de la solicitud req.body) } = req.body;

  // Realiza la inserción en la tabla de reservas
  const query = 'INSERT INTO Reservas (Fecha_Inicio, Duracion) VALUES (?, ?)';
  db.query(query, [ --Aquí debes proporcionar los valores correctos para Fecha_Inicio y Duracion ], (error, results) => {
    if (error) {
      console.error('Error al realizar la reserva:', error);
      return res.status(500).json({ mensaje: 'Error al realizar la reserva' });
    }

    console.log('Reserva realizada con éxito');
    return res.redirect('/pag_prin_cliente'); // Puedes redirigir a la página principal del cliente u otra según tus necesidades
  });
});

//--cancelar reservacion
app.delete('/cancelarReserva/:idReserva', (req, res) => {
    const idReserva = req.params.idReserva;

    const sql = `DELETE FROM Reservas WHERE Id_Reserva = ${idReserva}`;

    db.query(sql, (err, result) => {
        if (err) {
            console.log('Error al cancelar la reserva:', err);
            res.status(500).json({ error: 'Error interno del servidor' });
        } else {
            console.log('Reserva cancelada con éxito');
            res.status(200).json({ message: 'Reserva cancelada con éxito' });
        }
    });
});


//--actualizar datos del cliente
app.put('/actualizarPerfil/:idUsuario', (req, res) => {
    const idUsuario = req.params.idUsuario;
    const { nombre1, nombre2, apellido1, apellido2, email, contacto, usuario } = req.body;

    const sql = `UPDATE Datos_Personales SET 
                 Nombre1 = '${nombre1}', 
                 Nombre2 = '${nombre2}', 
                 Apellido1 = '${apellido1}', 
                 Apellido2 = '${apellido2}', 
                 Correo = '${email}', 
                 Celular = '${contacto}', 
                 Usuario = '${usuario}' 
                 WHERE Id_Dato_Personal = ${idUsuario}`;

    db.query(sql, (err, result) => {
        if (err) {
            console.log('Error al actualizar datos del perfil:', err);
            res.status(500).json({ error: 'Error interno del servidor' });
        } else {
            console.log('Datos del perfil actualizados con éxito');
            res.status(200).json({ message: 'Datos del perfil actualizados con éxito' });
        }
    });
});

//--guardar informacion del producto
app.post('/guardarProducto', (req, res) => {
    const {
        Id_Rol,
        Id_Peso,
        Id_Categoria,
        Id_Reserva,
        Nombre_Producto,
        Cantidad,
        Direccion,
        Num_Local,
        Url_Imagen,
        Codigo
    } = req.body;

    const sql = `INSERT INTO Productos (Id_Rol, Id_Peso, Id_Categoria, Id_Reserva, Nombre_Producto, Cantidad, Direccion, Num_Local, Url_Imagen, Codigo)
                 VALUES (${Id_Rol}, ${Id_Peso}, ${Id_Categoria}, ${Id_Reserva}, '${Nombre_Producto}', ${Cantidad}, '${Direccion}', ${Num_Local}, '${Url_Imagen}', ${Codigo})`;

    db.query(sql, (err, result) => {
        if (err) {
            console.log('Error al guardar el producto:', err);
            res.status(500).json({ error: 'Error interno del servidor' });
        } else {
            console.log('Producto guardado con éxito');
            res.status(200).json({ message: 'Producto guardado con éxito' });
        }
    });
});


//--borrar informacion producto
app.delete('/eliminarProducto/:idProducto', (req, res) => {
    const idProducto = req.params.idProducto;

    const sql = `DELETE FROM Productos WHERE Id_Producto = ${idProducto}`;

    db.query(sql, (err, result) => {
        if (err) {
            console.log('Error al eliminar el producto:', err);
            res.status(500).json({ error: 'Error interno del servidor' });
        } else {
            console.log('Producto eliminado con éxito');
            res.status(200).json({ message: 'Producto eliminado con éxito' });
        }
    });
});

//--control reservaciones
// Ruta para realizar la reserva
app.post('/reservar', (req, res) => {
    const { Fecha_Inicio, Duracion } = req.body;

    // Realiza la inserción en la tabla de reservas con el estado inicial 'En espera'
    const query = 'INSERT INTO Reservas (Fecha_Inicio, Duracion, Estado) VALUES (?, ?, ?)';
    db.query(query, [Fecha_Inicio, Duracion, 'En espera'], (error, results) => {
        if (error) {
            console.error('Error al realizar la reserva:', error);
            return res.status(500).json({ mensaje: 'Error al realizar la reserva' });
        }

        console.log('Reserva realizada con éxito');
        return res.redirect('/pag_prin_cliente'); // Puedes redirigir a la página principal del cliente u otra según tus necesidades
    });
});


//--actualizar datos del proveedor
app.put('/actualizarProveedor/:idProveedor', (req, res) => {
    const idProveedor = req.params.idProveedor;
    const {
        Nombre1,
        Nombre2,
        Apellido1,
        Apellido2,
        Correo,
        Celular,
        Direccion,
        Num_Local
    } = req.body;

    const sql = `UPDATE Datos_Personales 
                 SET Nombre1='${Nombre1}', Nombre2='${Nombre2}', Apellido1='${Apellido1}', Apellido2='${Apellido2}', 
                     Correo='${Correo}', Celular=${Celular}, Direccion='${Direccion}', Num_Local=${Num_Local} 
                 WHERE Id_Dato_Personal=${idProveedor}`;

    db.query(sql, (err, result) => {
        if (err) {
            console.log('Error al actualizar datos del proveedor:', err);
            res.status(500).json({ error: 'Error interno del servidor' });
        } else {
            console.log('Datos del proveedor actualizados con éxito');
            res.status(200).json({ message: 'Datos del proveedor actualizados con éxito' });
        }
    });
});

//--actualizar datos de usuarios
app.put('/actualizarUsuario/:idUsuario', (req, res) => {
    const idUsuario = req.params.idUsuario;
    const {
        nombre1,
        nombre2,
        apellido1,
        apellido2,
        Num_Doc,
        correo
    } = req.body;

    const sql = `UPDATE Datos_Personales 
                 SET Nombre1='${nombre1}', Nombre2='${nombre2}', Apellido1='${apellido1}', Apellido2='${apellido2}', 
                     Numero_Doc=${Num_Doc}, Correo='${correo}' 
                 WHERE Id_Dato_Personal=${idUsuario}`;

    db.query(sql, (err, result) => {
        if (err) {
            console.log('Error al actualizar datos del usuario:', err);
            res.status(500).json({ error: 'Error interno del servidor' });
        } else {
            console.log('Datos del usuario actualizados con éxito');
            res.status(200).json({ message: 'Datos del usuario actualizados con éxito' });
        }
    });
});

*/

  

app.listen(port, () => {
  console.log(`Servidor iniciado en http://localhost:${port}`);
});
