import { Component } from '@angular/core';

@Component({
  selector: 'app-form-perfil-proveedor',
  templateUrl: './form-perfil-proveedor.component.html',
  styleUrls: ['./form-perfil-proveedor.component.css']
})
export class FormPerfilProveedorComponent {

}
