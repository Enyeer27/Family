import { Component } from '@angular/core';

@Component({
  selector: 'app-pagina-principal-proveedor',
  templateUrl: './pagina-principal-proveedor.component.html',
  styleUrls: ['./pagina-principal-proveedor.component.css']
})
export class PaginaPrincipalProveedorComponent {

}
